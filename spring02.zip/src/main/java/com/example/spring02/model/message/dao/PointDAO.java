package com.example.spring02.model.message.dao;

public interface PointDAO {
	public void updatePoint(String userid, int point);
}
