package com.example.spring01;

import static org.junit.Assert.*;

import org.junit.Test;

public class HomeControllerTest {

	@Test
	public void testHome() {
		System.out.println("Hello world");
	}

}
