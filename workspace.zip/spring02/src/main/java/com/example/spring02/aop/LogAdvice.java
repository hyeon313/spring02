package com.example.spring02.aop;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LogAdvice {

	private static final Logger logger
		= LoggerFactory.getLogger(LogAdvice.class);
// 포인트컷 - 실행 시점, Around - 실행 전후
// Before, After, Around
// 컨트롤러, 서비스, dao의 모든 method 실행 전후에 logPrint method가 호출됨
// execution( 리턴 자료형 class.method(매개변수) )
//	@Around( // 요청 전후 
			// Controller로 끝나는 클래스의 모든 매소드들
//			"execution(* com.example.spring02.controller..*Controller.*(..))"
			// service 밑에 있는 Impl로 끝나는 클래스의 모든 매소드들
//			+ " or execution(* com.example.spring02.service..*Impl.*(..))"
			// dao 밑에 있는 Impl로 끝나는 클래스의 모든 매소드들
//			+ " or execution(* com.example.spring02.model..dao.*Impl.*(..))"
			//"execution(* com.example.spring02"
			//+ ".controller..*Controller.*(..))"
			//+ "or execution(* com.example.spring02"
			//+ ".service..*Impl.*(..))"
			//+ "or execution(* com.example.spring02"
			//+ ".model..dao.*Impl.*(..))"
//			)
	public Object logPrint(ProceedingJoinPoint joinPoint)
			throws Throwable {
			long start = System.currentTimeMillis();
			Object result = joinPoint.proceed(); // 기준!  위 호출 전   아래 호출 후
			// class name
			String type = 
					joinPoint.getSignature().getDeclaringTypeName();
			String name = "";
			if(type.indexOf("Controller") > -1) {
				name = "컨트롤러 \t: ";
			} else if(type.indexOf("Service") > -1) {
				name = "서비스Impl \t: ";
			} else if(type.indexOf("DAO") > -1) {
				name = "DAOImpl \t: ";
			}
			// method name
			logger.info(
					name + type + "." + joinPoint.getSignature().getName() + "()");
			// 매개변수
			logger.info(Arrays.toString(joinPoint.getArgs()));
			// 핵심로직으로 이동
			long end = System.currentTimeMillis();
			long time = end - start;
			logger.info("실행 시간 : " + time);
			return result;
		} 
	}
