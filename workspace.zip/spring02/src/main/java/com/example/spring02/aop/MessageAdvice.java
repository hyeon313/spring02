package com.example.spring02.aop;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class MessageAdvice {
	private static final Logger logger=
			LoggerFactory.getLogger(MessageAdvice.class);

	@Before( // 로그체크 
			"execution(* " //띄어쓰기 주의
			+ "com.example.spring02.service.message.MessageService*.*(..))")
	public void startLog(JoinPoint jp) {
		logger.info("핵심 업무 코드의 정보 : " + jp.getSignature());
		logger.info("method : " + jp.getSignature().getName());
		logger.info("매개변수" + Arrays.toString(jp.getArgs()));
	}
	
	@Around( // 시간
			"execution(* "
			+ "com.example.spring02.service.message.MessageService*.*(..))")
	public Object timeLog(ProceedingJoinPoint pjp) throws Throwable{
		long start = System.currentTimeMillis(); // 핵심업무 수행 전
		Object result = pjp.proceed();     // 핵심업무 실행
		long end = System.currentTimeMillis();  // 핵심업무 수행 후
		logger.info("실행시간 : " + pjp.getSignature().getName() + " : " + (end - start));
		logger.info("===================================");
		return result;
	}
}



